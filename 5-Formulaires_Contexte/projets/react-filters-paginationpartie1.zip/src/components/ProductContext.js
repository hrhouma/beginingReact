import React, { createContext, useState, useMemo } from 'react';

export const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [filter, setFilter] = useState('');
  const products = [
    { id: 1, name: 'Laptop', category: 'Electronics', price: 999 },
    { id: 2, name: 'Coffee Maker', category: 'Home Appliance', price: 250 },
    { id: 3, name: 'Book', category: 'Books', price: 20 },
  ];

  const filteredProducts = useMemo(() => {
    return products.filter(product => product.category.toLowerCase().includes(filter.toLowerCase()));
  }, [products, filter]);

  return (
    <ProductContext.Provider value={{ filter, setFilter, filteredProducts }}>
      {children}
    </ProductContext.Provider>
  );
};

export default ProductContext;