import React from 'react';

const FilterInput = ({ filter, setFilter }) => {
  return (
    <input
      type="text"
      value={filter}
      onChange={(e) => setFilter(e.target.value)}
      placeholder="Filter by category"
    />
  );
};

export default FilterInput;