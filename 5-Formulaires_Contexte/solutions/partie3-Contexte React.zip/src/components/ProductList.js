import React from 'react';
import { useSearch } from '../context/SearchContext';

const products = [
  { id: 1, name: 'Laptop', category: 'Electronics' },
  { id: 2, name: 'Book', category: 'Books' },
  { id: 3, name: 'Coffee Maker', category: 'Appliances' }
];

const ProductList = () => {
  const { searchTerm } = useSearch();
  
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <ul>
      {filteredProducts.map(product => (
        <li key={product.id}>{product.name}</li>
      ))}
    </ul>
  );
};

export default ProductList;
