import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { SearchProvider } from './context/SearchContext';
import SearchBar from './components/SearchBar';
import ProductList from './components/ProductList';
import ThemeToggle from './components/ThemeToggle';


const App = () => {
  return (
    <ThemeProvider>
      <SearchProvider>
        <ThemeToggle />
        <SearchBar />
        <ProductList />
      </SearchProvider>
    </ThemeProvider>
  );
};

export default App;
