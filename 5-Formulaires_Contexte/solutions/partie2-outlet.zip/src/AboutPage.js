import React from 'react';

function AboutPage() {
  return (
    <div>
      <h1>Page About Page</h1>
      <p>Bienvenue sur notre site web!</p>
    </div>
  );
}

export default AboutPage;