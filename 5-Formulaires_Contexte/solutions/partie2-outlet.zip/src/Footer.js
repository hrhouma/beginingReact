import React from 'react';

function Footer() {
  return (
    <footer>
      <p>© 2024 Mon Site Web</p>
    </footer>
  );
}

export default Footer;