import React from 'react';
import { Outlet } from 'react-router-dom';

function Layout() {
  return (
    <div>
      <Outlet />  {/* Ici, le contenu spécifique à chaque page sera rendu */}
    </div>
  );
}

export default Layout;