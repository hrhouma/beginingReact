import React from 'react';

function ContactPage() {
  return (
    <div>
      <h1>Page de CONTACT</h1>
      <p>Contactez-nous !</p>
    </div>
  );
}

export default ContactPage;