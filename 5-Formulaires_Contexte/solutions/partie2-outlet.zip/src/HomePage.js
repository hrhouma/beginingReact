import React from 'react';

function HomePage() {
  return (
    <div>
      <h1>Page d'Accueil</h1>
      <p>Bienvenue sur notre site web!</p>
    </div>
  );
}

export default HomePage;