const Pays = () => {
    const optionsPays = [
        { value: "Canada", key: "Canada", text: "Canada" },
        { value: "Etas Unis", key: "Etas Unis", text: "Etas Unis" },
        { value: "Mexique", key: "Mexique", text: "Mexique" },
        { value: "Uganda", key: "Uganda", text: "Uganda" },
        { value: "Chine", key: "Chine", text: "Chine" },
        { value: "Japon", key: "Japon", text: "Japon" },
        { value: "Algérie", key: "Algérie", text: "Algérie" },
        { value: "Australie", key: "Australie", text: "Australie" },

    ];
    return (optionsPays)
}

export default Pays
