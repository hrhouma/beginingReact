import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Navigation() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState('');
  const [username, setUsername] = useState('');

  const handleUserNavigate = () => {
    navigate(`/user/${userId}`);
  };

  const handleProfileNavigate = () => {
    navigate(`/profile/${username}`);
  };

  return (
    <nav>
      <Link to="/">Accueil</Link> | <Link to="/about">À propos</Link>
      <div>
        <input
          type="text"
          placeholder="User ID"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
        />
        <button onClick={handleUserNavigate}>Go to User</button>
      </div>
      <div>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <button onClick={handleProfileNavigate}>Go to Profile</button>
      </div>
    </nav>
  );
}

function Layout({ children }) {
  return (
    <>
      <Navigation />
      <div>{children}</div>
    </>
  );
}

export default Layout;