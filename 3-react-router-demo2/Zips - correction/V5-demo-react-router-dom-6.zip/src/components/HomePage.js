import { useNavigate } from 'react-router-dom';

function HomePage() {
    let navigate = useNavigate();
    return (
      <button onClick={() => navigate('/about')}>Go to About</button>
    );
  }
  export default HomePage;