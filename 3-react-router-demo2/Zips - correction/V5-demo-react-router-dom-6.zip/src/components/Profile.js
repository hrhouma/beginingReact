import React from 'react';
import { useParams } from 'react-router-dom';
import './Profile.css';

function Profile() {
  let { username } = useParams();
  let highlight = username.length > 5;
  return <h2 className={highlight ? 'profile-highlights' : 'profile-normal'}>Profile Page: {username}</h2>;
}

export default Profile;