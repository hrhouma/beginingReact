import React from 'react';
import { useParams } from 'react-router-dom';

function UserPage() {
  let { userId } = useParams();
  return <div>User ID: {userId}</div>;
}

export default UserPage;