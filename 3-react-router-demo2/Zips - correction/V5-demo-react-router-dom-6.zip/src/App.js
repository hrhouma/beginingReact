import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import AboutPage from './components/AboutPage';
import HomePage from './components/HomePage';
import Layout from './components/Layout';
import UserPage from './components/UserPage'; // Importez UserPage
import Profile from './components/Profile'; // Importez Profile

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout><HomePage /></Layout>,
  },
  {
    path: "/about",
    element: <Layout><AboutPage /></Layout>,
  },
  {
    path: "/user/:userId", // Ajoutez la route pour UserPage
    element: <Layout><UserPage /></Layout>,
  },
  {
    path: "/profile/:username", // Ajoutez la route pour Profile
    element: <Layout><Profile /></Layout>,
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;